export enum RoleEnum {
  admin,
  recruteur,
  candidat,
}
